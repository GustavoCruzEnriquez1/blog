import { LitElement, html, css } from 'lit-element';

class ArticleList extends LitElement {
    static styles = css`
        /* Estilos para el listado de artículos */
    `;

    render() {
        return html`
            <section id="article-module">
                <h2>Consulta de Artículos</h2>
                <button id="view-all">Ver Todos los Artículos</button>
            </section>
        `;
    }
}

customElements.define('article-list', ArticleList);
