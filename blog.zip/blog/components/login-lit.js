import { ArticleEditor} from './article-editor';

customElements.define('login-lit', ArticleEditor);
