import { LitElement, html, css } from 'lit-element';

class ArticleEditor extends LitElement {
    static styles = css`
        /* Estilos para el módulo de edición de artículos */
    `;

    render() {
        return html`
            <section id="article-editor">
                <h2>Crear o Editar Artículo</h2>
                <form id="editor-form">
                    <label for="article-title">Título:</label>
                    <input type="text" id="article-title" required>
                    <label for="article-content">Contenido:</label>
                    <textarea id="article-content" rows="6" required></textarea>
                    <button type="submit">Guardar Artículo</button>
                </form>
            </section>
        `;
    }
}

customElements.define('article-editor', ArticleEditor);
